package org.sa.animal.domain;

import java.sql.Date;

public class ImageVO {
    private Integer ino;
    private String url;
    private Integer animalNumber;
    private Date regdate;
    private Date updatedate;
}
